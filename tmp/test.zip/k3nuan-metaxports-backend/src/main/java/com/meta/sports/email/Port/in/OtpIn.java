package com.meta.sports.email.Port.in;

public interface OtpIn {

    boolean validateOtp(String email,String otp);
}
