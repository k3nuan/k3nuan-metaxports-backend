package com.meta.sports.events.utils;


public class EventSource {

    public static final String SPORTS_SFT = "SPORTS_SFT";

}
