package com.meta.sports.global.domain;

public class DataResponse {

    private Integer reference;

    private String device;


    public Integer getReference() {
        return reference;
    }

    public void setReference(Integer reference) {
        this.reference = reference;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }
}
