package com.meta.sports.global.exceptions;

public class NotFoundException extends RuntimeException {

}