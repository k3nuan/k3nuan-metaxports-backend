
--EVENTS TYPES

INSERT INTO event_type VALUES (400, 'Authentication Failure', '');

